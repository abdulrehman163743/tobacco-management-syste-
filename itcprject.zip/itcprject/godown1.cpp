#include<stdio.h>
int main()
{
	godowndetails();
}
int godowndetails()
{
	int godown1[1000];
	int godown2[1000];
	int godown3[1000];
	int godown4[1000];
	int remaining;
	int godown5[1000];
	int taskchecker;
	int godown6[1000];
	int startingrange;
	int ans;
	char godowncheck[1000];
	int calculation;
	int r;
	printf("1.godown1\n2.godown2\n3.godown3\n4.godown4\n5.godown5\n6.godown6\n");
	printf("from which godown you want to add deduct == \n");
	fflush(stdin);
	gets(godowncheck);
	printf("press 1 to exit the godown area\n");
//	printf("%s",godowncheck);
	do
	{
		if(strcmp("godown1",godowncheck)==0)
	{
		printf("enter starting range of godown1 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\nthe remaining carton is == %d",remaining);
				godown2(remaining);
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		
	}
	else if(strcmp("godown2",godowncheck)==0)
	{
		printf("enter current range of godown2 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		
	}
	else if(strcmp("godown3",godowncheck)==0)
	{	printf("enter starting range of godown3 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
	else if(strcmp("godown4",godowncheck)==0)
	{	printf("enter starting range of godown4 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
	else if(strcmp("godown5",godowncheck)==0)
	{
			printf("enter starting range of godown5 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("godown6",godowncheck)==0)
	{
			printf("enter starting range of godown6 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);	
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
			printf("\n");
			scanf("%d",&taskchecker);
			printf("\n");
	}
}
	while(taskchecker!=1);
	
	
	
}
