/*  ITC Project Spring 2017
 ****Work Started on 14 MArch 2017******
 Group Members are 
 1 .Abdul REhman 16K-3743
 2.  Jahania Shah 16K-3744
 3.   Faizan Ahmed 16K-3754

*/

#include<stdio.h>
#include<string.h>
#include<conio.h>
#include<windows.h>
#include<dos.h>

int i,j,len;
	int godown1[1000];
	int godown2[1000];
	int godown3[1000];
	int godown4[1000];
	int godown5[1000];
	int taskchecker;
	int godown6[1000];
	int remaining;
	int startingrange=0;
	int ans;
	char godowncheck[1000];
	int calculation;
	int r;

void TitlePage(void)
{
	char AbdulRehman[]={"-------1. Abdul Rehman Shahid  16K-3743------"};
	char Jahania[]={"-------2. Jahania Shah Bukhari 16K-3744------"} ;
	char Faizan[]={"-------3. Faizan Ahmed Khan    16K-3754------"};
	
	char FAST[100]={"----------FAST NATIONAL UNIVERSITY----------"};
	char ITC[100]={"--------------SPRING 2017---------------"};
	char COURSE[100]={"    ------------ITC PROJECT-------------"};
	char teacher[100]={"Course Teacher:  Sir Nauman Atique "};
	char labteacher[100]={"Lab Instructor:  Ms Solat Jabeen Sheikh"};
	char members[50]={"     ----------Group Members---------"};
	printf("\n\n\n\n\t\t\t\t\t");
	len=strlen(FAST);
	for(i=0;i<len;i++)
	{
		printf("%c",FAST[i]);
		Sleep(100);
	}
	
	printf("\n\n\t\t\t\t\t  ");
	int lenitc=strlen(ITC);
	for(i=0;i<lenitc;i++)
	{
		printf("%c",ITC[i]);
		Sleep(100);
	}
	printf("\n\n\t\t\t\t\t");
	
		int lencourse=strlen(COURSE);
	for(i=0;i<lencourse;i++)
	{
		printf("%c",COURSE[i]);
		Sleep(100);
	}
	
	printf("\n\n\t\t\t\t\t");
	
			int lenteacher=strlen(teacher);
	for(i=0;i<lenteacher;i++)
	{
		printf("%c",teacher[i]);
		Sleep(100);
	}
	
	printf("\n\n\t\t\t\t\t");
	
	int lenlabteacher=strlen(labteacher);
	for(i=0;i<lenlabteacher;i++)
	{
		printf("%c",labteacher[i]);
		Sleep(100);
	}
	
	printf("\n\n\n\n\t\t\t\t\t");
	
	int lenmembers=strlen(members);
	for(i=0;i<lenmembers;i++)
	{
		printf("%c",members[i]);
		Sleep(100);
	}
	
	printf("\n\n\t\t\t\t\t\t\tSection B");
      printf("\n\n\n\n\t\t\t\t\t");	
		int lenAbdulRehman=strlen(AbdulRehman);
	for(i=0;i<lenAbdulRehman;i++)
	{
		printf("%c",AbdulRehman[i]);
		Sleep(100);
	}
	
	printf("\n\n\t\t\t\t\t");
	
		int lenjahania=strlen(Jahania);
	for(i=0;i<lenjahania;i++)
	{
		printf("%c",Jahania[i]);
		Sleep(100);
	}
	
		printf("\n\n\t\t\t\t\t");
	
	int lenfaizan=strlen(Faizan);
	for(i=0;i<lenfaizan;i++)
	{
		printf("%c",Faizan[i]);
		Sleep(100);
	}
		
} //TITLE Function Ends Here.

void EnterContinue()
{
	int enter;
	printf("\n\n\t\t\t\t\t\tPress Enter To Continue.");
	scanf("/0",&enter);
}

int main()
{
	char ch;
	char a=219,b=222;
	int qq;
	int pp;
	system("COLOR 4f");
/*	TitlePage();
	EnterContinue();*/
	system("cls");
	

	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t We Are Testing Your Patience\n\n\n");
	printf("\t\t\t\t\t\t\t\t");
	for(qq=0;qq<=15;qq++)
	{
		printf("%c",a);
		printf("\r");
		printf("\t\t\t\t\t\t\t\t");
		for(qq=0;qq<=15;qq++)
		{
			printf("%c",a);
			for(pp=0;pp<=18e6;pp++);
		}	
	}
	system("cls");
	int i=1;
	int cnici=1;
	
	system("COLOR 4f");
	
	char check[100];
	char title[100]={"\n\n\n\t\t\t\t----------BAHRIA TOBACCO COMPANY MANAGMENT SYSTEM----------"};
	int title_len=strlen(title);
	int i_title;
	printf("\n\n\t");
	for(i=0;i<title_len;i++)
	{
		printf("%c",title[i]);
		Sleep(100);
		
	}
//	printf("\t\t\t TOBACCO COMPANY MANAGEMENT SYSTEM");
	printf("\n\n\n");
	int employeecheck;
	int verification;
	printf("\t\t\t\tFOR ADMIN PRESS == 1\t\t\t TO EXIT PRESS ANY KEY.\n\n");
	scanf("%d",&verification);
	if(verification==1)
	{
		printf("\n\n");
		printf("\t\t\t\t\t Administrator Office \n\n");
		printf(" \t\t\t\t\tEnter password :  ");	
		int k=1;
		do
		{
			for(i=0;i<4;i++)
			{
				check[i]=getch();
				printf("*");
				
			}
			//scanf("%s",check);
			
			if(strcmp("saad",check)==0)
		{
			//system("COLOR 4f");
			int x,y;
			system("cls");
			x=admin();
			y=adminOptions();
			printf("\n");
			break;
		}
		else
		{
			printf("\nIncorrect Password.\nEnter again\n");
		}
		k++;
		}
		while(k<=3);
		
	}

}
	
int askTasknum()
{
	printf("\n\n\tEnter the Number For the Task You want To Perform.\n");
	
}

int adminOptions()
	{
		int tasknum;
		printf("\n1. Billing.\n2. Warehouse Details.\n3. Statement of Accounts.\n4. Back\n");
		askTasknum();
        scanf("%d",&tasknum);
        if(tasknum==1)
        {
        	billing();
		}
		else if(tasknum==2)
		{
			godowndetails(); 
		}
		else if(tasknum==3)
		{
			printf("\n you cannot go direct to this area first u have to perform billing or dodown task :\n");
			adminOptions();
		}
		else if (tasknum==4)
		{
			admin();
			
		}
	}
//>>>>>>>>>>>>>>>>>>>>>>>>>>>billing<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<	



int EnterProduct()
{
	system("cls");
	printf("\n\n\n\t\t");
	int p;
	
	char billingtitle[100]={"------Billing Department------"};
	int len=strlen(billingtitle);
	for(i=0;i<len;i++)
	{
		printf("%c",billingtitle[i]);
		Sleep(10);
	}
	
	//printf("       \n\t\t------Billing Department------ \n");
	printf("\n\n \t\t\t\t\t                  To Exit Press '1'");
	
	
	char product[1000];
	
	int ans;
	int quantity;
	int price;
	
	

}
	
int billing()
{	
	int quantity;
	int price;
	char product[1000];

	
		printf("\nEnter Product == ");
		fflush(stdin);
		gets(product);
		if(strcmp("dunhil light",product)==0)
	{
		printf("Enter price == ");
		scanf("%d",&price);
		printf("Enter qauntity == ");
		scanf("%d",&quantity);
		printf("dunhil light == [%d] * [%d] == %d",price,quantity,price*quantity);
		
		/*	printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
			else
			{
				billing();
				
			}*/
		
	}
	else if(strcmp("benson & hedge",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter quantity == ");
		scanf("%d",&quantity);
		printf("benson & hedge == [%d] * [%d] == %d",price,quantity,price*quantity);
	/*	printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("gold leaf",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold leaf == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
		/*	if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("gold leaf special",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold leaf special == [%d] * [%d] == %d",price,quantity,price*quantity);
	/*	printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	} 
	else if(strcmp("capstain ft",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("capstan ft == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("capstan original",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("capstan special == [%d] * [%d] == %d",price,quantity,price*quantity);
/*		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("gold flake",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold flake == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("embassy",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("embassy == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("pall mall",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pall mall == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("marlboro gold",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("marlboro gold == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("morven gold",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("morven gold == [%d] * [%d] == %d",price,quantity,price*quantity);
	/*	printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("k2",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("k2 == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
			else
			{
				
			}*/
	}
	else if(strcmp("melbron",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("melbron == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("pine light pakistan",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine light pakistan == [%d] * [%d] == %d",price,quantity,price*quantity);
		/*printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("pine light",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine light == [%d] * [%d] == %d",price,quantity,price*quantity);
/*		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	}
	else if(strcmp("pine green",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine green == [%d] * [%d] == %d",price,quantity,price*quantity);
/*		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}*/
	
	}
	

		int pro;
		printf("\n u want to go to admin option press 1 or to print the bill press 2\n");
		scanf("%d",&pro);
		if(pro==1)
		{
			adminOptions();
		}
		else if(pro==2)
		{
			statementofaccount(product,price,quantity);
		}
		
	
	
		
}


//>>>>>>>>>godown details<<<<<<<<<
int godowndetails()
{
	printf("1.godown1\n2.godown2\n3.godown3\n4.godown4\n5.godown5\n6.godown6\n");
	printf("from which godown you want to add deduct == \n");
	int check;
	scanf("%d",&check);
	printf("\n\n");
	if(check==1)
	{
		gdown1();
	}
	else if(check==2)
	{
		gdown2();
	}
else if(check==3)
	{
		gdown3();
	}
	else if(check==4)
	{
		gdown4();
	}
	else if(check==5)
	{
		gdown5();
	}
	else if(check==6)
	{
		gdown6();
	}
	
}
int gdown1()
{
	printf("enter starting range of godown1 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\nthe remaining carton is == %d\n",remaining);
				gdown2(remaining);
			}
}
			else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}
}
int gdown2(int p)
{
	printf("enter starting range of godown2 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+p;
		printf("the staring range of godown 2 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown3(remaining);
			}
			
}		
	else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}	

}
int gdown3()
{
	printf("enter starting range of godown3 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+remaining;
		printf("the staring range of godown 3 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown4(remaining);
			}
			
}
		else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}

}
int gdown4()
{
	printf("enter starting range of godown4 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+remaining;
		printf("the staring range of godown 4 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown5(remaining);
			}
			
}
		else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}
}

int gdown5()	
{
	printf("enter starting range of godown5 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+remaining;
		printf("the staring range of godown 5 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown6(remaining);
			}
			
}

		else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}

}
int gdown6()
{
	printf("enter starting range of godown6 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+remaining;
		printf("the staring range of godown 6 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown1(remaining);
			}			
}

		else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}

}
int admin()  //Functio to print Welcome Admin.
{
	char welcomeadmin[100]={"\n\t\t     -----Welcome Admin-----\n"};
	int len_admin=strlen(welcomeadmin);
	int i;
	for(i=0;i<len_admin;i++)
	{
		printf("%c",welcomeadmin[i]);
		Sleep(100);
	}
	//printf("\t\t\t\tWelcome Admin. \n");
}
int registration()
{

	printf("you can registered \n");
}
int statementofaccount(char product[],int price,int quantity)
{
	static int q=1;
	printf("\nprint the bill of %d obeject == \n",q);
	printf("%s\n",product);
	printf("the price of product is == %d\n",price);
	printf("the number of quantity is == %d\n",quantity);
	printf("\n\n\nthe total cost of [%d] price * [%d] product == [%d]",price,quantity,price*quantity);
	int kk;
	printf("\n\nif you want to add product again press '0'\n\n or if you want to go to main menu press 'any key numeric value' == \t");
	scanf("%d",&kk);
	if(kk==0)
	{
		q++;
		billing();
	}
}

