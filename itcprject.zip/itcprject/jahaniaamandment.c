#include<stdio.h>
#include<string.h>
#include<conio.h>
#include<windows.h>
#include <ctype.h>
struct employeedetail
{
	char name[1000];
	char adress[1000];
	char cnic[1000];
	int cellnumber[1000];
	int salary;
	char designation[1000];
	
}ed[1000];
int main()
{
	int i;
	int cnici=1;
	int employeecheck;
	int verification;
	
	char check[100];
	system("COLOR 3F");
	
	
	printf("\t\t\t TOBACCO COMPANY MANAGEMENT SYSTEM");
	printf("\n\n\n");

	printf("FOR ADMIN PRESS == 1 \t FOR EMPLOYEE PRESS == 2 \t TO EXIT PRESS ANY KEY.\n\n");
	scanf("%d",&verification);
	if(verification==1)
	{
		printf("\n\n");
		printf("\t\t\t Administrator Office \n\n");
		printf("Enter password : \n\n");	
		int k=1;
		do
		{
			for(i=0;i<4;i++)
			{
				check[i]=getch();
				printf("*");
				
			}
			//scanf("%s",check);
			
			if(strcmp("saad",check)==0)
		{
			system("COLOR 0A");
			int x,y;
			x=admin();
			y=adminOptions();
			printf("\n");
			break;
		}
		else
		{
			printf("\nIncorrect Password.\nEnter again\n");
		}
		k++;
		}
		while(k<=3);
		
	}
	else if(verification==2) //FOR EMPLOYEES
	{
		EmployersArea();
		
		printf("TO ENTER EMPLOYEE DETAIL PRESS === 1\n");
		scanf(" %d",&employeecheck);
		int numofemployee;
		printf("\n\n");
		printf("How many Number of Employees detail You want to Add == ");
		scanf("%d",&numofemployee);
	
		
	
		printf("\n\n");
		if(employeecheck==1)
		{
			for(i=0;i<numofemployee;i++)
			{
				printf("FOR %d EMPLOYEE",i+1);
				printf("\n\n\n");
				printf("\t\t\t\t1-enter name \n");
				printf("\n\t\t\t\t");
			    fflush(stdin) ;
			    gets(ed[i].name);
			  	fflush(stdin) ;
				printf("\n\t\t\t\t2-ENTER ADRESS \n");
				printf("\n\t\t\t\t");
				fflush(stdin);
				gets(ed[i].adress);
				fflush(stdin);
				printf("\n\t\t\t\t3-ENTER CONTACT NUMBER\n");
				printf("\n\t\t\t\t");
				scanf("%d",&ed[i].cellnumber);
				
				do
				{
					printf("\n\t\t\t\t4-ENTER 15 DIGIT CNIC  \n");
					printf("\t\t\t\tfor e.g(xxxxx-xxxxxxx-x)\n");
					printf("\n\t\t\t\t");
					
				  	fflush(stdin);
				 	gets(ed[i].cnic);
			        fflush(stdin);
					if(strlen(ed[i].cnic)==15)
					{
						break;
						
					}
					else
					{
						printf("\n\n\t\t\t\tENTER CORRECT FORMAT!\n\n");
						cnici++;
						
					}
				}while(cnici<=3);
				
				printf("\n\t\t\t\t5-ENTER DESIGNATION\n");
				printf("\n\t\t\t\t");	
				fflush(stdin);
				gets(ed[i].designation) ;
				fflush(stdin);
				printf("\n\t\t\t\t6-ENTER SALARY \n");
				printf("\n\t\t\t\t");
				scanf("%d",&ed[i].salary);
			}
			
			
			
		}
			
		for(i=0;i<numofemployee;i++)
		{
			printf("NAME=");
			puts(ed[i].name);
			puts(ed[i].adress);
			puts(ed[i].cnic);
			printf("%d\n",ed[i].salary);
			puts(ed[i].designation);
		}
	
	
	}
	else
	{
		printf("\n\n");
		exit(verification);
	}

} ///MAIN FUNCTION  ENDS HERE.

void EmployeeDetail()
{
		
	
	
}



void EmployersArea()
{
	
		system("COLOR 0e");
		printf("\n\n");
		printf("\t\t\tWelcome to Employee's Area.");
		printf("\n");
		
	
}
int askTasknum()   //Asks No of TAsk from user   to perform 
{
	printf("\n\n\tEnter the Number For the Task You want To Perform.\n");
	
}

int adminOptions()
	{
		int tasknum;
		printf("\n\n\t\t\tWelcome Administrator.\n\n");
		printf("\n1. Products List .\n2. Billing.\n3. Staff Attendance.\n4. Staff Information.\n5. Statement of Accounts.");
		askTasknum();
        scanf("%d",&tasknum);
        if(tasknum==1)
        {
        	Attendance();
        	
        	
		}
	}
	

int admin()
{

}
int registration()
{
	printf("you can registered \n");
}
int Attendance()
{
	int i=1;
	int numAttendance;
	printf("\n\n\t\t\tAttendance Register.");
	printf("\n\n 1.Mark Employees Attendance.\t2.View Employees Attendance. ");
	do
	{
		
		askTasknum();
	    scanf("%d",&numAttendance);
	    if(numAttendance==1)
	    {
	    	markAttendance();
	    	break;
	    	
	    	
		}
		else if(numAttendance==2)
		{
			viewAttendance();
			break;
		}
		else
		{
			i++;
		}
		
		
	}while(i<=3);
	
}

int markAttendance()  //Function to mark attendance
{
	
}

int viewAttendance() //Function to view attendance
{
	
}





























/*if(getchar()=='a' || getchar()=='A')
	{
		int admincontrol;
		admincontrol=admin();
	}
	
	if(getchar()=='R' || 'r')
	{
		int registrationcontrol;
		registrationcontrol=registration();
	}*/
