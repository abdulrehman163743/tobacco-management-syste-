
#include<stdio.h>
int godown1[1000];
int godown2[1000];
int godown3[1000];
int godown4[1000];
int godown5[1000];
int taskchecker;
int godown6[1000];
int startingrange;
int ans;
char godowncheck[1000];
int calculation;
int r;
int remaining;
int main()
{
	printf("1.godown1\n2.godown2\n3.godown3\n4.godown4\n5.godown5\n6.godown6\n");
	int check;
	scanf("%d",&check);
	printf("\n\n");
	if(check==1)
	{
		gdown1();
	}
	else if(check==2)
	{
		gdown2();
	}
else if(check==3)
	{
		gdown3();
	}
	else if(check==4)
	{
		gdown4();
	}
	else if(check==5)
	{
		gdown5();
	}
	else if(check==6)
	{
		gdown6();
	}
}
int gdown1()
{
	printf("enter starting range of godown1 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\nthe remaining carton is == %d\n",remaining);
				gdown2(remaining);
			}
}
			else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}
}
int gdown2(int p)
{
	printf("enter starting range of godown2 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+p;
		printf("the staring range of godown 2 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown3(remaining);
			}
			
}		
	else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}	

}
int gdown3()
{
	printf("enter starting range of godown3 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+remaining;
		printf("the staring range of godown 3 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown4(remaining);
			}
			
}
		else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}

}
int gdown4()
{
	printf("enter starting range of godown4 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+remaining;
		printf("the staring range of godown 4 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown5(remaining);
			}
			
}
		else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}
}

int gdown5()	
{
	printf("enter starting range of godown5 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+remaining;
		printf("the staring range of godown 5 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown6(remaining);
			}
			
}

		else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}

}
int gdown6()
{
	printf("enter starting range of godown6 == ");
		scanf("%d",&startingrange);
		startingrange=startingrange+remaining;
		printf("the staring range of godown 6 is == %d",startingrange);
		printf("\nif you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
				remaining=startingrange-10000;
				printf("\n%d\n",remaining);
				gdown1(remaining);
			}
			
}

		else if(calculation==2)
			{
				printf("how many carton u want deduct == ");
				scanf("%d",&r);
				startingrange=startingrange-r;
				printf("your godown has == %d capacity ",startingrange);
			}

}
