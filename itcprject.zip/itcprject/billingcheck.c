#include<stdio.h>
#include<string.h>

int main()
{
	billing();
}
int billing()
{	
	int quantity;
	int price;
	char product[1000][1000];

		printf("\nEnter Product == ");
		fflush(stdin);
		gets(product);
		if(strcmp("dunhil light",product)==0)
	{
		printf("Enter price == ");
		scanf("%d",&price);
		printf("Enter qauntity == ");
		scanf("%d",&quantity);
		printf("dunhil light == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	}
	else if(strcmp("benson & hedge",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter quantity == ");
		scanf("%d",&quantity);
		printf("benson & hedge == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	}
	else if(strcmp("gold leaf",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold leaf == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	}
	else if(strcmp("gold leaf special",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold leaf special == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	} 
	else if(strcmp("capstain ft",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("capstan ft == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	}
	else if(strcmp("capstan original",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("capstan special == [%d] * [%d] == %d",price,quantity,price*quantity);

	}
	else if(strcmp("gold flake",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold flake == [%d] * [%d] == %d",price,quantity,price*quantity);
		
	}
	else if(strcmp("embassy",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("embassy == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	}
	else if(strcmp("pall mall",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pall mall == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	}
	else if(strcmp("marlboro gold",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("marlboro gold == [%d] * [%d] == %d",price,quantity,price*quantity);
		
	}
	else if(strcmp("morven gold",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("morven gold == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	}
	else if(strcmp("k2",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("k2 == [%d] * [%d] == %d",price,quantity,price*quantity);
	
	}
	else if(strcmp("melbron",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("melbron == [%d] * [%d] == %d",price,quantity,price*quantity);
		
	}
	else if(strcmp("pine light pakistan",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine light pakistan == [%d] * [%d] == %d",price,quantity,price*quantity);
		
	}
	else if(strcmp("pine light",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine light == [%d] * [%d] == %d",price,quantity,price*quantity);

	}
	else if(strcmp("pine green",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine green == [%d] * [%d] == %d",price,quantity,price*quantity);

	
	}
	

		int pro;
		printf("\n u want to go to admin option press 1 or to print the bill press 2\n");
		scanf("%d",&pro);
		if(pro==1)
		{
			adminOptions();
		}
		else if(pro==2)
		{
			statementofaccount(product,price,quantity);
		}		
}
int adminOptions()
{
	
}
int statementofaccount(char product[],int price,int quantity)
{
	static int q=1;
	printf("\ntotal bill of %d object is \n",q);
	printf("%s\n",product);
	printf("the price of product is == %d\n",price);
	printf("the number of quantity is == %d\n",quantity);
	printf("\n\n\nthe total cost of [%d] price * [%d] product == [%d]",price,quantity,price*quantity);
	int kk;
	printf("\n\nif you want to add product again press '0'\n\n or if you want to go to main menu press 'any key numeric value' == \t");
	scanf("%d",&kk);
	if(kk==0)
	{
		q++;
		billing();
	}
	
}

