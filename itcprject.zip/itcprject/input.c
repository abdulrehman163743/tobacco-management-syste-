#include<stdio.h>
int main()
{
	char name[5][100];
	namesss(name);
}
void namesss(char name[][100])
{
	printf("enter name == \n");
	gets(namesss[5][]);
}
