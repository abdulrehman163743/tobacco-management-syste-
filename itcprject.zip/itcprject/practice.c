
#include<stdio.h>
#include<string.h>
#include<conio.h>
#include<windows.h>
#include<dos.h>
struct employeedetail
{
	char name[1000];
	char adress[1000];
	char cnic[1000];
	int cellnumber[1000];
	int salary;
	char designation[1000];
	
}ed[1000];
int main()
{
	char ch;
	char a=219,b=221;
	int qq;
	int pp;
	system("COLOR 4f");
	
	
	system("cls");
	

	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t We Are Testing Your Patience\n\n\n");
	printf("\t\t\t\t\t\t\t\t");
	for(qq=0;qq<=15;qq++)
	{
		printf("%c",a);
		printf("\r");
		printf("\t\t\t\t\t\t\t\t");
		for(qq=0;qq<=15;qq++)
		{
			printf("%c",a);
			for(pp=0;pp<=18e6;pp++);
		}	
	}
	system("cls");
	int i=1;
	int cnici=1;
	system("COLOR 3F");
	int numofemployee;
	char check[100];
	char title[100]={"\n\n\n----------SHAH TOBACCO COMPANY MANAGMENT SOFTWARE----------"};
	int title_len=strlen(title);
	int i_title;
	printf("\n\n\t");
	for(i=0;i<title_len;i++)
	{
		printf("%c",title[i]);
		Sleep(100);
		
	}
//	printf("\t\t\t TOBACCO COMPANY MANAGEMENT SYSTEM");
	printf("\n\n\n");
	int employeecheck;
	int verification;
	printf("FOR ADMIN PRESS == 1 \t FOR EMPLOYEE PRESS == 2 \t TO EXIT PRESS ANY KEY.\n\n");
	scanf("%d",&verification);
	if(verification==1)
	{
		printf("\n\n");
		printf("\t\t\t Administrator Office \n\n");
		printf("Enter password : \n\n");	
		int k=1;
		do
		{
			for(i=0;i<4;i++)
			{
				check[i]=getch();
				printf("*");
				
			}
			//scanf("%s",check);
			
			if(strcmp("saad",check)==0)
		{
			system("COLOR 0A");
			int x,y;
			system("cls");
			x=admin();
			y=adminOptions();
			printf("\n");
			break;
		}
		else
		{
			printf("\nIncorrect Password.\nEnter again\n");
		}
		k++;
		}
		while(k<=3);
		
	}
	else if(verification==2)
	{
		system("COLOR 0e");
		printf("\n\n");
		printf("\t\t\tWelcome to Employee's Area.");
		printf("\n");
		printf("TO ENTER EMPLOYEE DETAIL PRESS === 1\n");
		scanf(" %d",&employeecheck);
		printf("\n\n");
		printf("How many Number of Employees detail You want to Add == ");
		scanf("%d",&numofemployee);
		printf("\n\n");
		if(employeecheck==1)
		{
			for(i=0;i<numofemployee;i++)
			{
				printf("FOR %d EMPLOYEE",i+1);
				printf("\n\n\n");
				printf("\t\t\t\t1-enter name \n");
				printf("\n\t\t\t\t");
			    fflush(stdin) ;
			    gets(ed[i].name);
			  	fflush(stdin) ;
				printf("\n\t\t\t\t2-ENTER ADRESS \n");
				printf("\n\t\t\t\t");
				fflush(stdin);
				gets(ed[i].adress);
				fflush(stdin);
				printf("\n\t\t\t\t3-ENTER CONTACT NUMBER\n");
				printf("\n\t\t\t\t");
				scanf("%d",&ed[i].cellnumber);
				
				do
				{
					printf("\n\t\t\t\t4-ENTER 15 DIGIT CNIC  \n");
					printf("\t\t\t\tfor e.g(xxxxx-xxxxxxx-x)\n");
					printf("\n\t\t\t\t");
					
				  	fflush(stdin);
				 	gets(ed[i].cnic);
			        fflush(stdin);
					if(strlen(ed[i].cnic)==15)
					{
						break;
						
					}
					else
					{
						printf("\n\n\t\t\t\tENTER CORRECT FORMAT!\n\n");
						cnici++;
						
					}
				}while(cnici<=3);
				
				printf("\n\t\t\t\t5-ENTER DESIGNATION\n");
				printf("\n\t\t\t\t");	
				fflush(stdin);
				gets(ed[i].designation) ;
				fflush(stdin);
				printf("\n\t\t\t\t6-ENTER SALARY \n");
				printf("\n\t\t\t\t");
				scanf("%d",&ed[i].salary);
			}
			
			
			
		}
	}
	else
	{
		printf("\n\n");
		exit(verification);
	}
	
/*	for(i=0;i<numofemployee;i++)
{
	printf("NAME=");
	puts(ed[i].name);
	puts(ed[i].adress);
	puts(ed[i].cnic);
	printf("%d\n",ed[i].salary);
	puts(ed[i].designation);
}*/
	
	
	
	
	
	
	
	
	
	
	/*
	
	
	printf("if you want to register then press == R or r \n\n");
	printf("if you donot want to use it the press x\n\n");
	scanf("%s",check);

	
	else if (strcmp("r",check)==0)
	{
			int b;
		b=registration();
	

	}
*/
}
int askTasknum()
{
	printf("\n\n\tEnter the Number For the Task You want To Perform.\n");
	
}

int adminOptions()
	{
		int tasknum;
		printf("\n1. Attendance Register.\n2. Billing.\n3. Godown Details\n4. Statement of Accounts.");
		askTasknum();
        scanf("%d",&tasknum);
        if(tasknum==1)
        {
        	Attendance();
        	
        	
		}
		else if(tasknum==2)
		{
			billing();
		}
		else if (tasknum==3)
		{
			godowndetails();
		}
	}
//>>>>>>>>>>>>>>>>>>>>>>>>>>>billing<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<	
int billing()

{
	int p;
	
	printf("       \n\t\t------Billing Department------ \n");
	printf("\n \t\t\t\t\t                  To Exit Press '1'");
	
	
	char product[1000];
	
	int ans;
	int quantity;
	int price;
	do
	{
		printf("\nEnter Product == ");
		fflush(stdin);
		gets(product);
		if(strcmp("dunhil light",product)==0)
	{
		printf("Enter price == ");
		scanf("%d",&price);
		printf("Enter qauntity == ");
		scanf("%d",&quantity);
		printf("dunhil light == [%d] * [%d] == %d",price,quantity,price*quantity);

			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		
	}
	else if(strcmp("benson & hedge",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter quantity == ");
		scanf("%d",&quantity);
		printf("benson & hedge == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("gold leaf",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold leaf == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("gold leaf special",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold leaf special == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	} 
	else if(strcmp("capstain ft",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("capstan ft == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("capstan original",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("capstan special == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("gold flake",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("gold flake == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("embassy",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("embassy == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("pall mall",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pall mall == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("marlboro gold",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("marlboro gold == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("morven gold",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("morven gold == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("k2",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("k2 == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("melbron",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("melbron == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("pine light pakistan",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine light pakistan == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("pine light",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine light == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("pine green",product)==0)
	{
		printf("enter price == ");
		scanf("%d",&price);
		printf("enter queantity == ");
		scanf("%d",&quantity);
		printf("pine green == [%d] * [%d] == %d",price,quantity,price*quantity);
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	
	}
	printf("\n\n");
	scanf("%d",&p);
	printf("\n\n");
}
	while(p!=1);
	
}
//>>>>>>>>>godown details<<<<<<<<<
int godowndetails()
{
	int godown1[1000];
	int godown2[1000];
	int godown3[1000];
	int godown4[1000];
	int godown5[1000];
	int taskchecker;
	int godown6[1000];
	int startingrange;
	int ans;
	char godowncheck[1000];
	int calculation;
	int r;
	printf("1.godown1\n2.godown2\n3.godown3\n4.godown4\n5.godown5\n6.godown6\n");
	printf("from which godown you want to add deduct == \n");
	fflush(stdin);
	gets(godowncheck);
	printf("press 1 to exit the godown area\n");
//	printf("%s",godowncheck);
	do
	{
		if(strcmp("godown1",godowncheck)==0)
	{
		printf("enter starting range of godown1 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		
	}
	else if(strcmp("godown2",godowncheck)==0)
	{
		printf("enter current range of godown2 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		
	}
	else if(strcmp("godown3",godowncheck)==0)
	{	printf("enter starting range of godown3 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
	else if(strcmp("godown4",godowncheck)==0)
	{	printf("enter starting range of godown4 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
	else if(strcmp("godown5",godowncheck)==0)
	{
			printf("enter starting range of godown5 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
	}
	else if(strcmp("godown6",godowncheck)==0)
	{
			printf("enter starting range of godown6 == ");
		scanf("%d",&startingrange);
		printf("if you want to add press == 1");
		printf("\n if you want to deduct press == 2");
		printf("\n\n");
		scanf("%d",&calculation);
		if(calculation==1)
		{
			printf("how many carton u want add == ");
			scanf("%d",&r);
			startingrange=startingrange+r;
			printf("your godown has == %d capacity ",startingrange);
			if (startingrange>10000)
			{
				printf("limit exceed !!!");
			}
			printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
		}
		else if(calculation==2)
		{
			printf("how many carton u want deduct == ");
			scanf("%d",&r);
			startingrange=startingrange-r;
			printf("your godown has == %d capacity ",startingrange);	
		}
		printf("\nEnter '0' for menu or any key to repeat task.");
			scanf("%d",&ans);
			if(ans==0)
			{
				adminOptions();
			}
			printf("\n");
			scanf("%d",&taskchecker);
			printf("\n");
	}
}
	while(taskchecker!=1);
	
	
	
}

int admin()  //Functio to print Welcome Admin.
{
	char welcomeadmin[100]={"\n\t\t     -----Welcome Admin-----\n"};
	int len_admin=strlen(welcomeadmin);
	int i;
	for(i=0;i<len_admin;i++)
	{
		printf("%c",welcomeadmin[i]);
		Sleep(100);
	}
	//printf("\t\t\t\tWelcome Admin. \n");
}
int registration()
{
	printf("you can registered \n");
}
int Attendance()
{
	int i=1;
	int numAttendance;
	printf("\n\n\t\t\tAttendance Register.");
	printf("\n\n 1.Mark Employees Attendance.\t2.View Employees Attendance. ");
	do
	{
		
		askTasknum();
	    scanf("%d",&numAttendance);
	    if(numAttendance==1)
	    {
	    	markAttendance();
	    	break;
	    	
	    	
		}
		else if(numAttendance==2)
		{
			viewAttendance();
			break;
		}
		else
		{
			i++;
		}
		
		
	}while(i<=3);
	
}

int markAttendance()  //Function to mark attendance
{
	
}

int viewAttendance() //Function to view attendance
{
	
}


