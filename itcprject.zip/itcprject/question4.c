/*Define a structure to store the following student data: gpa, major, address 
(consisting of  street address, city, state,  zip) consisting of up to six records. 
Define whatever data types are needed. HINT: define another structure to hold the address. 
Refer the last code provided in the manual for help.*/
#include<stdio.h>

struct record
{
	float gpa;
	char major[100];
};
struct adress
{
	char stadress[1000];
	char city[1000];
	char state[1000];
	int zip;
};
int main()
{
	struct record in[1000];
	struct adress >[1000];
	int n;
	printf("enter number of person == ");
	scanf("%d",&n);
	getInvoiceAmount(in,n);
}
int print(struct record rc[],struct adress ad[],int size)
{
	
}
